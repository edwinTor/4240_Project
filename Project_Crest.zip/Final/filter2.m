function filter2( img, filImg )
%FILTER2- 'filImg' is the image with the crest values detected and we are
%iterating through the image to elevate the corresponding values in the
%original image by 100. Then we will display the meshgrid image of the
%resulting function.

    [a,b] = size(filImg);
    for i = 1:a
        for j = 1:b
            if filImg(i,j) == 1
                img(i,j) = img(i,j) + 1000;
            end
        end
    end
    
    [x2,y2] = meshgrid(1:500, 1:500);
    Z = img( 1:500, 1:500 );
    figure, surf(x2,y2,Z);

end

