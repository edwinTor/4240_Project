% NOTE - to display a different quadrant of the image when diplaying the
% meshgrid(3D image) the values are:
%   Quadrant 1: imgFile(1:250,1:250)
%   Quadrant 2: imgFile(1:250,251:500)
%   Quadrant 3: imgFile(251:500,1:250)
%   Quadrant 4: imgFile(251:500,251:500)


% Reading in the image.
[org, map]= imread('duneLiDARs.png','png');

% Displaying Original Image
% 'org' is the copy to be manipulated.
figure, imshow(org,map), title('Original Image');

% Copying original image.
im = org;
%figure, imshow(im,map);

% Mesh Grid of the original immage before alterations.
[x1,y1] = meshgrid(1:250, 251:500);
Z1 = org( 1:250, 251:500 );
figure, surf(x1,y1,Z1);

% Finding the gradient magnitude and direction.
% Only the magnitude will be used.
[Gmag, Gdir] = imgradient(org,'sobel');
% Applying the gradient function to the gradient magnitude.
[x,y] = gradient(Gmag);

% 'x' is the newly acquired image and will be filtered and displayed.
org = edgeF(x);
figure, imshow(org, map);

% Cleaning the image.
BW3 = bwmorph(org,'clean',Inf);
figure
imshow(BW3, map), title('Clean')

% Thickening the image.
BW2 = bwmorph(BW3,'thicken',1);
figure
imshow(BW2, map), title('Thicken')

% Reducing the width of the lines to 1 pixel.
BW4 = bwmorph(BW2,'thin',Inf);
figure
imshow(BW4, map), title('thin');

% Removing branching pixels.
BW5 = bwmorph(BW4,'spur',3);
figure
imshow(BW5, map), title('spur');

% Cleaning the image again.
BW6 = bwmorph(BW5,'clean',Inf);
figure
imshow(BW6, map), title('Clean')

% Used to overlay the images and elevate the areas in which the crest is
% detected.
filter2(im, BW6);

% Overlaying the images and displaying them.
C = imfuse(BW6,im);
C=rgb2gray(C);
figure, imshow(C, []);



%processImg(org,im);