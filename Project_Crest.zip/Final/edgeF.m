function n = edgeF( img )
%EDGEF- Finding pixel values within the threshold values and rising their
%value to the max.
%
    [a,b] = size(img);
    img = uint16(img);
    for i=1:a
        for j=1:b 
            % Threshold section. lower and upper, respectively.
            if (img(i,j) >= 500 && img(i,j) <=2800)
                if j-2 > 0
                    img(i,j-2) = intmax('uint16');
                else
                    img(i,j) = intmax('uint16');
                end
            else
                img(i,j) = 0;
            end
         end
    end
    n = img;

end

